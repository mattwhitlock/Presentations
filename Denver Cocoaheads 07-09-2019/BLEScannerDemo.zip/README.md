Simple BLE Scanner Demo for July 2019 Cocoaheads Presentation

Slides at https://www.slideshare.net/MattWhitlock/a-brief-introduction-to-bluetooth-low-energy-ble-on-ios
